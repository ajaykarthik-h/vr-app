package csuohio.edu.driverhealthmonitor.sensor.data;

public class SkinTempData extends SensorData {

    private double tempDataC;
    private double tempDataF;

    public SkinTempData(double tempDataC, long timeStamp) {
        super(timeStamp);

        this.tempDataC = tempDataC;
        this.tempDataF = ((tempDataC * 9) / 5) + 32;
    }

    public double getTempDataC() {
        return tempDataC;
    }

    public void setTempDataC(double tempDataC) {
        this.tempDataC = tempDataC;
    }

    public double getTempDataF() {
        return tempDataF;
    }

    public void setTempDataF(double tempDataF) {
        this.tempDataF = tempDataF;
    }
}
