package csuohio.edu.driverhealthmonitor.sensor.service;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.microsoft.band.BandClient;
import com.microsoft.band.BandClientManager;
import com.microsoft.band.BandException;
import com.microsoft.band.BandIOException;
import com.microsoft.band.BandInfo;
import com.microsoft.band.ConnectionState;
import com.microsoft.band.sensors.BandAccelerometerEvent;
import com.microsoft.band.sensors.BandAccelerometerEventListener;
import com.microsoft.band.sensors.BandGsrEvent;
import com.microsoft.band.sensors.BandGsrEventListener;
import com.microsoft.band.sensors.BandHeartRateEvent;
import com.microsoft.band.sensors.BandHeartRateEventListener;
import com.microsoft.band.sensors.BandRRIntervalEvent;
import com.microsoft.band.sensors.BandRRIntervalEventListener;
import com.microsoft.band.sensors.BandSensorManager;
import com.microsoft.band.sensors.BandSkinTemperatureEvent;
import com.microsoft.band.sensors.BandSkinTemperatureEventListener;
import com.microsoft.band.sensors.GsrSampleRate;
import com.microsoft.band.sensors.SampleRate;

import java.lang.ref.WeakReference;
import java.util.logging.Logger;

import csuohio.edu.driverhealthmonitor.sensor.broadcast.SensorBroadcastReceiver;
import csuohio.edu.driverhealthmonitor.sensor.data.AccData;
import csuohio.edu.driverhealthmonitor.sensor.data.GSRData;
import csuohio.edu.driverhealthmonitor.sensor.data.HRData;
import csuohio.edu.driverhealthmonitor.sensor.data.RRData;
import csuohio.edu.driverhealthmonitor.sensor.data.SensorData;
import csuohio.edu.driverhealthmonitor.sensor.data.SkinTempData;
import csuohio.edu.driverhealthmonitor.util.Constants;

public class SensorService extends Service implements BandGsrEventListener,
        BandSkinTemperatureEventListener, BandAccelerometerEventListener,
        BandHeartRateEventListener, BandRRIntervalEventListener {

    private final Logger logger = Logger.getLogger(getClass().getName());
    private final IBinder binder = new SensorServiceBinder();
    private BandClient bandClient;

    public SensorService() {
        bandClient = null;
    }

    @Override
    public void onCreate() {
        logger.info(String.format("%s started...", getClass().getSimpleName()));

        // Subscribe to the sensors.
        new SensorService.SensorSubscriptionTask(this).execute();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        logger.info("Service onStartCommand called.");
        // Make sure the service get restarted once destroyed by the system.
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // If the BandClient is not null, unregister all the listeners.
        if (bandClient != null) {
            try {
                bandClient.getSensorManager().unregisterAllListeners();
            } catch (BandIOException e) {
                logger.severe("Couldn't unregister event listeners.");
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onBandGsrChanged(BandGsrEvent bandGsrEvent) {
        if (bandGsrEvent != null) {
            GSRData data = new GSRData(bandGsrEvent.getResistance(), bandGsrEvent.getTimestamp());
            broadcastSensorData(data);
        }
    }

    @Override
    public void onBandAccelerometerChanged(BandAccelerometerEvent bandAccelerometerEvent) {
        if (bandAccelerometerEvent != null) {
            AccData data = new AccData(bandAccelerometerEvent.getAccelerationX(),
                    bandAccelerometerEvent.getAccelerationY(),
                    bandAccelerometerEvent.getAccelerationZ(),
                    bandAccelerometerEvent.getTimestamp());
            broadcastSensorData(data);
        }
    }

    @Override
    public void onBandHeartRateChanged(BandHeartRateEvent bandHeartRateEvent) {
        if (bandHeartRateEvent != null) {
            HRData data = new HRData(bandHeartRateEvent.getHeartRate(),
                    bandHeartRateEvent.getQuality().toString(),
                    bandHeartRateEvent.getTimestamp());
            broadcastSensorData(data);
        }
    }

    @Override
    public void onBandRRIntervalChanged(BandRRIntervalEvent bandRRIntervalEvent) {
        if (bandRRIntervalEvent != null) {
            RRData data = new RRData(bandRRIntervalEvent.getInterval(),
                    bandRRIntervalEvent.getTimestamp());
            broadcastSensorData(data);
        }
    }

    @Override
    public void onBandSkinTemperatureChanged(BandSkinTemperatureEvent bandSkinTemperatureEvent) {
        if (bandSkinTemperatureEvent != null) {
            SkinTempData data = new SkinTempData(bandSkinTemperatureEvent.getTemperature(),
                    bandSkinTemperatureEvent.getTimestamp());
            broadcastSensorData(data);
        }
    }

    private void broadcastSensorData(SensorData data) {
        Intent broadcastIntent = new Intent(SensorBroadcastReceiver.SENSOR_BROADCAST_ACTION);
        broadcastIntent.putExtra(Constants.DATA_ATR, data);
        sendBroadcast(broadcastIntent);
    }

    private boolean getConnectedBandClient() throws InterruptedException, BandException {
        if (bandClient == null) {
            BandInfo[] devices = BandClientManager.getInstance().getPairedBands();
            if (devices.length == 0) {
                logger.warning("Couldn't find any connected Band devices.");
                return false;
            }
            bandClient = BandClientManager.getInstance().create(getBaseContext(), devices[0]);
        }

        logger.info("Band is connecting...");
        return bandClient.connect().await() == ConnectionState.CONNECTED;
    }

    /**
     * Subscribe to the sensors of the connected band client.
     */
    private static class SensorSubscriptionTask extends AsyncTask<Void, Void, Void> {

        private WeakReference<SensorService> contextReference;

        SensorSubscriptionTask(SensorService context) {
            contextReference = new WeakReference<>(context);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            // Get a reference to the context if its still there.
            SensorService context = contextReference.get();

            try {
                if (context.getConnectedBandClient()) {
                    int hardwareVersion = Integer.parseInt(context.bandClient.getHardwareVersion().await());

                    if (hardwareVersion >= 20) {
                        context.logger.info("Band is connected...");
                        BandSensorManager sensorManager = context.bandClient.getSensorManager();
                        sensorManager.registerGsrEventListener(context, GsrSampleRate.MS200);
                        sensorManager.registerAccelerometerEventListener(context, SampleRate.MS128);
                        sensorManager.registerHeartRateEventListener(context);
                        sensorManager.registerRRIntervalEventListener(context);
                        sensorManager.registerSkinTemperatureEventListener(context);
                    } else {
                        context.logger.info("The Gsr sensor is not supported with your band version. Microsoft Band 2 is required");
                    }
                } else {
                    context.logger.warning("Band isn't connected. Please make sure bluetooth is on and the band is in range.");
                }
            } catch (BandException e) {
                String exceptionMessage;

                switch (e.getErrorType()) {
                    case UNSUPPORTED_SDK_VERSION_ERROR:
                        exceptionMessage = "Microsoft Health BandService doesn't support your SDK Version. Please update to latest SDK.\n";
                        break;
                    case SERVICE_ERROR:
                        exceptionMessage = "Microsoft Health BandService is not available. Please make sure Microsoft Health is installed and that you have the correct permissions.\n";
                        break;
                    default:
                        exceptionMessage = "Unknown error occurred: " + e.getMessage();
                        break;
                }

                context.logger.severe(exceptionMessage);
            } catch (Exception e) {
                context.logger.severe("Unknown error occurred: " + e.getMessage());
            }

            return null;
        }
    }

    public class SensorServiceBinder extends Binder {

        public SensorService getService() {
            logger.info(this.getClass().getSimpleName() + " getService");
            return SensorService.this;
        }
    }
}
