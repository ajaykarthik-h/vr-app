package csuohio.edu.driverhealthmonitor.ui.fragment;

import android.app.Activity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Locale;

import csuohio.edu.driverhealthmonitor.R;
import csuohio.edu.driverhealthmonitor.sensor.broadcast.SensorBroadcastCallback;
import csuohio.edu.driverhealthmonitor.sensor.broadcast.SensorBroadcastReceiver;
import csuohio.edu.driverhealthmonitor.sensor.data.AccData;
import csuohio.edu.driverhealthmonitor.sensor.data.GSRData;
import csuohio.edu.driverhealthmonitor.sensor.data.HRData;
import csuohio.edu.driverhealthmonitor.sensor.data.RRData;
import csuohio.edu.driverhealthmonitor.sensor.data.SensorData;
import csuohio.edu.driverhealthmonitor.sensor.data.SkinTempData;
import csuohio.edu.driverhealthmonitor.util.Constants;

public class HomeFragment extends Fragment implements SensorBroadcastCallback {
    private SensorBroadcastReceiver sensorBroadcastReceiver;

    private TextView hrTextView;
    private TextView skinTempTextView;
    private TextView accTextView;
    private TextView gsrTextView;
    private TextView rrTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        hrTextView = view.findViewById(R.id.hrTextView);
        skinTempTextView = view.findViewById(R.id.skinTempTextView);
        accTextView = view.findViewById(R.id.accTextView);
        gsrTextView = view.findViewById(R.id.gsrTextView);
        rrTextView = view.findViewById(R.id.rrTextView);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        // Register the broadcast receiver.
        IntentFilter sensorBroadcastIntentFilter = new IntentFilter(SensorBroadcastReceiver.SENSOR_BROADCAST_ACTION);
        sensorBroadcastReceiver = new SensorBroadcastReceiver(this);

        Activity parent = getActivity();
        if (parent != null) {
            parent.registerReceiver(sensorBroadcastReceiver, sensorBroadcastIntentFilter);
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        // Unregister the broadcast receiver.
        Activity parent = getActivity();
        if (parent != null) {
            parent.unregisterReceiver(sensorBroadcastReceiver);
        }
    }

    @Override
    public void onCallback(SensorData data) {
        if (data instanceof AccData) {
            AccData accData = (AccData) data;
            accTextView.setText(String.format(Locale.getDefault(),
                    "x: %.2f y: %.2f z: %.2f", accData.getX(), accData.getY(), accData.getZ()));
        } else if (data instanceof GSRData) {
            GSRData gsrData = (GSRData) data;
            gsrTextView.setText(gsrData.getGsrValue());
        } else if (data instanceof HRData) {
            HRData hrData = (HRData) data;
            hrTextView.setText(String.format(Locale.getDefault(),
                    "%d (%s)", hrData.getHeartRate(), hrData.getQuality()));
        } else if (data instanceof RRData) {
            RRData rrData = (RRData) data;
            rrTextView.setText(String.format(Locale.getDefault(),
                    "%.2f", rrData.getRr()));
        } else if (data instanceof SkinTempData) {
            SkinTempData skinTempData = (SkinTempData) data;
            skinTempTextView.setText(String.format(Locale.getDefault(),
                    "%.2f %sC (%.2f %sF)", skinTempData.getTempDataC(), Constants.DEGREE_SYM,
                    skinTempData.getTempDataF(), Constants.DEGREE_SYM));
        }
    }
}