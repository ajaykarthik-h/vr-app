package csuohio.edu.driverhealthmonitor.sensor.data;

public class HRData extends SensorData {

    private int heartRate;
    private String quality;

    public HRData(int heartRate, String quality, long timeStamp) {
        super(timeStamp);

        this.heartRate = heartRate;
        this.quality = quality;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }
}
