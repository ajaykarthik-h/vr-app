package csuohio.edu.driverhealthmonitor.sensor.data;

import java.io.Serializable;

public abstract class SensorData implements Serializable {
    private long timeStamp;

    SensorData(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    long getTimeStamp() {
        return timeStamp;
    }

    void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }
}
