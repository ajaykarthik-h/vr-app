package csuohio.edu.driverhealthmonitor.util;

public final class Constants {

    public static final String DATA_ATR = "data";
    public static final String DEGREE_SYM = "\u00b0";
}
