package csuohio.edu.driverhealthmonitor.sensor.broadcast;

import csuohio.edu.driverhealthmonitor.sensor.data.SensorData;

public interface SensorBroadcastCallback {
    void onCallback(SensorData data);
}
