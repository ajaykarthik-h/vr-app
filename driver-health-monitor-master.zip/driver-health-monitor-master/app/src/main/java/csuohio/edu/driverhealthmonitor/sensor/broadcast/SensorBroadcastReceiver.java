package csuohio.edu.driverhealthmonitor.sensor.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import csuohio.edu.driverhealthmonitor.sensor.data.SensorData;
import csuohio.edu.driverhealthmonitor.util.Constants;

public class SensorBroadcastReceiver extends BroadcastReceiver {

    public static final String SENSOR_BROADCAST_ACTION =
            "csuohio.edu.driverhealthmonitor.sensor.broadcast";

    private SensorBroadcastCallback sensorBroadcastCallback;

    public SensorBroadcastReceiver(SensorBroadcastCallback sensorBroadcastCallback) {
        this.sensorBroadcastCallback = sensorBroadcastCallback;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getExtras() != null)
            sensorBroadcastCallback.onCallback((SensorData) intent.getExtras()
                    .getSerializable(Constants.DATA_ATR));
    }
}
