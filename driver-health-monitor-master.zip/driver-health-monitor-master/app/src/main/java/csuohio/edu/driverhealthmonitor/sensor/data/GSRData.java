package csuohio.edu.driverhealthmonitor.sensor.data;

public class GSRData extends SensorData {

    private int gsrValue;

    public GSRData(int gsrValue, long timeStamp) {
        super(timeStamp);

        this.gsrValue = gsrValue;
    }

    public int getGsrValue() {
        return gsrValue;
    }

    public void setGsrValue(int gsrValue) {
        this.gsrValue = gsrValue;
    }
}
