package csuohio.edu.driverhealthmonitor.sensor.data;

public class RRData extends SensorData {

    private double rr;

    public RRData(double rr, long timeStamp) {
        super(timeStamp);

        this.rr = rr;
    }

    public double getRr() {
        return rr;
    }

    public void setRr(double rr) {
        this.rr = rr;
    }
}
