package csuohio.edu.driverhealthmonitor.ui;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import java.util.logging.Logger;

import csuohio.edu.driverhealthmonitor.R;
import csuohio.edu.driverhealthmonitor.sensor.service.SensorService;
import csuohio.edu.driverhealthmonitor.sensor.service.SensorService.SensorServiceBinder;
import csuohio.edu.driverhealthmonitor.ui.fragment.HeartRateFragment;
import csuohio.edu.driverhealthmonitor.ui.fragment.HomeFragment;
import csuohio.edu.driverhealthmonitor.ui.fragment.TempFragment;

public class MainActivity extends AppCompatActivity implements ServiceConnection {

    private final Logger logger = Logger.getLogger(getClass().getName());

    private boolean isBound;

    private SensorService sensorService;

    private DrawerLayout drawerLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.content_frame, new HomeFragment());
        transaction.commit();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionbar = getSupportActionBar();
        if (actionbar != null) {
            actionbar.setDisplayHomeAsUpEnabled(true);
            actionbar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }

        drawerLayout = findViewById(R.id.drawer_layout);

        drawerLayout.addDrawerListener(
                new DrawerLayout.DrawerListener() {
                    @Override
                    public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
                        // Respond when the drawer's position changes
                    }

                    @Override
                    public void onDrawerOpened(@NonNull View drawerView) {
                        // Respond when the drawer is opened
                    }

                    @Override
                    public void onDrawerClosed(@NonNull View drawerView) {
                        // Respond when the drawer is closed
                    }

                    @Override
                    public void onDrawerStateChanged(int newState) {
                        // Respond when the drawer motion state changes
                    }
                }
        );

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                // set item as selected to persist highlight
                menuItem.setChecked(true);
                // close drawer when item is tapped
                drawerLayout.closeDrawers();

                FragmentTransaction transaction;

                switch (menuItem.getItemId()) {
                    case R.id.nav_heart_rate:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.content_frame, new HeartRateFragment());
                        transaction.commit();

                        break;
                    case R.id.nav_temp:
                        transaction = getSupportFragmentManager().beginTransaction();
                        transaction.replace(R.id.content_frame, new TempFragment());
                        transaction.commit();

                        break;
                }

                return true;
            }
        });
    }

    /**
     * Bind the service to the activity.
     */
    private void doBindService() {
        bindService(new Intent(this, SensorService.class), this, Context.BIND_AUTO_CREATE);
        isBound = true;

        logger.info("Service bound to " + getClass().getSimpleName());
    }

    /**
     * Unbind the service from the activity.
     */
    private void doUnbindService() {
        if (isBound) {
            unbindService(this);
            isBound = false;

            logger.info("Service unbound from " + getClass().getSimpleName());
        }
    }

    @Override
    protected void onPause() {
        if (isBound) {
            doUnbindService();
        }

        super.onPause();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        doBindService();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }

        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        // Access the service object via the IBinder.
        SensorServiceBinder sensorServiceBinder = (SensorServiceBinder) iBinder;
        sensorService = sensorServiceBinder.getService();

        logger.info("OnServiceConnected is called.");
    }

    @Override
    public void onServiceDisconnected(ComponentName componentName) {
        sensorService = null;
    }
}
